Welcome to the AEPsych yanny-laurel demo! To get started, follow these steps:

1) Install the AEPsych server on your local machine, if you haven't already.
Installation instructions can be found at https://aepsych.org/#quickstart

2) Start a local AEPsych server.
Refer to https://aepsych.org/ for troubleshooting.

3) Launch the aepsych_unity.exe file at the root of this archive.