INSTALLATION
____________

1) Extract the zip archive an accessible location on your device.

2) Unblock app from Apple Quarantine: Open terminal to the directory containing the 
Unzipped app, then run:
   > xattr -r -d com.apple.quarantine mac_particle_experiment.app

3) Install the AEPsych server on your local machine. Refer to https://aepsych.org/#quickstart

4) Start a local AEPsych server. 

5) Open the root directory of the extracted archive from step 1, and launch the application found within.

6) ⌘ + Q to quit.


TROUBLESHOOTING
_______________

If “Cannot Open Application”:
	- Open terminal to the same directory as this README then run:
	> chmod -R +x mac_particle_experiment.app/Contents/MacOS

If Failed to Connect:
	- Ensure you started the AEPsych local server correctly. You should see the following message: "Server up, waiting for connections!", prior to launching the unity app. Refer to https://aepsych.org/#quickstart for more info.
