VR Throw Optimizer Instructions

1) Download and unzip the ThrowOptimizer.zip file from Google Drive

2) Install AEPsych (see aepsych.org for instructions)

3) Plug your Oculus Quest 2 into your PC, and enable Quest Link.

4) Start your local AEPsych server

5) Double-click the "Throw Optimizer" Unity executable at the root directory of the unzipped ThrowOptimizer file.


If you have any problems with setup, message the AEPsych Support group: 
https://fb.workplace.com/groups/aepsychsupport/